package observer2;

import observer2.SwingFacade;

public class Main {
    public static void main(String[] args) {
        MainPanel mainPanel = new MainPanel();
        SwingFacade.launch(SwingFacade.createTitledPanel("Observer Pattern Example", mainPanel), "Assignment3");
    }
}
