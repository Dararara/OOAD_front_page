package observer2;

public interface Observer {
    void update(char keyChar);
}
