package observer3;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class GreenBall extends Ball implements Subject{
    private List<Ball> observerBalls = new ArrayList<>();

    public GreenBall(Color color, int xSpeed, int ySpeed, int ballSize) {
        super(color, xSpeed, ySpeed, ballSize);
    }

    @Override
    public void update(Ball redBall) {

    }

    public List<Ball> getObserverBalls(){
        return this.observerBalls;
    }
    @Override
    public void addBall(Ball ball) {
        this.observerBalls.add(ball);
    }

    @Override
    public void deleteBall(Ball ball) {
        this.observerBalls.remove(ball);
    }

    @Override
    public void notifyBalls() {
        this.observerBalls.forEach(o->o.update(this));
    }

}
