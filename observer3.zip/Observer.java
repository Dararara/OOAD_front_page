package observer3;

public interface Observer {
    void update(Ball redBall);
}
