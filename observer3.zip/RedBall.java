package observer3;

import java.awt.*;

public class RedBall extends Ball{
    private int r_x;
    private int r_y;
    private double dis;
    public RedBall(Color color, int xSpeed, int ySpeed, int ballSize) {
        super(color, xSpeed, ySpeed, ballSize);
    }

    @Override
    public void update(Ball greenBall) {
        this.r_x = greenBall.getX();
        this.r_y = greenBall.getY();
        this.dis = Math.sqrt(Math.pow(r_x-this.getX(),2)+Math.pow(r_y-this.getY(),2));
        if(dis < 100){
            this.setX(this.getX()-50);
            this.setY(this.getY()-50);
        }
    }
}
